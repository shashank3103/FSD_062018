import { Injectable } from '@angular/core';
import {Http, Response, Headers, RequestOptions} from '@angular/http';
import {Task} from '../entity/task';
import { map, catchError } from 'rxjs/operators';
//import {environment} from './environments/environment';

@Injectable({
  providedIn: 'root'
})

export class TaskService {

  url: string;
  private task:Task;
    
  constructor(private http : Http) {
    //this.url = environment.tmBaseAPIUrl + 'tasks/';
    this.url = 'http://localhost:8080/' + 'tasks/';
  }

  addTask(task : Task){
    
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers : headers });
    return this.http.post(this.url, task, options)
    .pipe(map((res) => (res.status == 201)));  
    
  } 
    
  
  getTaskList(){
    return this.http.get(this.url).pipe(map(res => res.json()));
  }

  getTask(taskId : number){
    let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: cpHeaders });
    return this.http.get(this.url + taskId, options)
      .pipe(map(res => res.json()));
  }

  updateTask(task : Task){

    let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: cpHeaders });

    return this.http.put(this.url + task.taskId, JSON.stringify(task), options)
      .pipe(map(res => res.json()));
    
  }

  deleteTask(taskId : number){
    return this.http.put(this.url, JSON.stringify(taskId))
      .pipe(map(res => res.json()));
  }

  private handleError(error: any): Promise<any> {
    console.error('Error', error); 
    return Promise.reject(error.message || error);
  }

  public setter(task:Task){
    this.task=task;
  }

 public getter(){
   return this.task;
 }

/*
export class TaskService {

  private baseUrl:string='http://localhost:8080/spa'
  private headers = new Headers({'Content-Type':'application/json'});
  private options = new RequestOptions({headers:this.headers});
  constructor(private _http:Http) { }
  private task:Task;

  public getTasks()
  {
    
    return this._http.get(this.baseUrl + '/tasks',this.options)
    .pipe(map((response:Response)=>response.json()));
    
     //catchError(this.errorHandler));
  }

  public getTask(id:Number)
  {
    return this._http.get(this.baseUrl + '/task/'+id,this.options)
    .pipe(map((response:Response)=>response.json()));
    //catchError(this.errorHandler));
  }

  public deleteTask(id:Number)
  {
    return this._http.delete(this.baseUrl + '/task/'+id,this.options)
    .pipe(map((response:Response)=>response.json()));
    //catchError(this.errorHandler));
  }

  public createTask(task:Task)
  {
    return this._http.post(this.baseUrl + '/task',JSON.stringify(task), this.options)
    .pipe(map((response:Response)=>response.json()))
    //catchError(this.errorHandler));
  }

  public updateTask(task:Task)
  {
    return this._http.put(this.baseUrl + '/task',JSON.stringify(task), this.options)
    .pipe(map((response:Response)=>response.json()))
    //catchError(this.errorHandler));
  }

  errorHandler(error:Response)
  {
    //return Observable.throw(error||"Error ! Solve it.")
    return console.log(error||"Error ! Solve it.")
  }

  public setter(task:Task){
    this.task=task;
  }

 public getter(){
   return this.task;
 } */
}
