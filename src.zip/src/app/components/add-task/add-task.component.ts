import { Component, OnInit } from '@angular/core';
import { Task } from '../../entity/task';
import { TaskService } from '../../shared_service/task.service';
import { Parent } from '../../entity/parent'
import { DatePipe } from '@angular/common';
import {Router} from '@angular/router';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent implements OnInit {

  task : Task;
  pTask : Task;
  parentTask : Parent;
  
  parentId : number;
  taskArr : Task[];
  taskService : TaskService;
  stDt : string;
  

  constructor(taskService : TaskService, private _router:Router) { 
    this.taskService = taskService;
    this.task = new Task();
    
  }

  
  ngOnInit() {
    this.taskService.getTaskList().subscribe(data => {
      this.taskArr = data;
    }, err => {alert('Service temporarily unavailable')});
  }

  addTask(){
        
    if(this.task.pId != null && this.task.pId != 0){
      
      let index = -1;
      if(this.taskArr.length > 0){
        console.log('Fetching parent task..');
        for(let i=0;i<this.taskArr.length;i++){
          if(this.taskArr[i].taskId==this.task.pId){
            index=i;
            break;
          }
        }
  
        this.pTask = this.taskArr[index];
        console.log('Parent task found..' + this.pTask.taskId);

      }

      if(this.task.startDate>this.task.endDate){
        alert('Start Date must be smaller than End Date !!');
      }
      
      if((this.pTask != null) && (this.pTask.taskName != '')){
        this.parentTask = new Parent();
        this.parentTask.parentTaskName = this.pTask.taskName;
        
        this.task.parentTask = this.parentTask;
        console.log('Parent ID before save :: ' + this.task.parentTask.parentTaskId);
        console.log('Parent Name before save :: ' + this.task.parentTask.parentTaskName);
      }
    }
    
    this.taskService.addTask(this.task).subscribe(isSaved =>{
       if(isSaved){
        //alert('Task saved')
        this._router.navigate(['/viewAll']);
      }else{
        alert('Failed to save Task')
      }
    }, err => {alert(err + 'Save Service temporarily unavailable')});
    this.task = new Task();
  }
}
