import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TaskService } from '../../shared_service/task.service';
import { Task } from '../../entity/task';
import { Parent } from '../../entity/parent';
import {Router} from '@angular/router';

@Component({
  selector: 'app-edit-task',
  templateUrl: './edit-task.component.html',
  styleUrls: ['./edit-task.component.css']
})
export class EditTaskComponent implements OnInit {

  route : ActivatedRoute;
  taskService : TaskService;
  task : Task;
  taskId : number;
  taskArr : Task[];
  parentTask : Parent;

  constructor(route : ActivatedRoute, taskService : TaskService, private _router:Router) { 
    this.route = route;
    this.taskService = taskService;
    this.task = new Task();
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      
      this.taskId = params['taskId'];
         
      this.taskService.getTask(this.taskId).subscribe(data => {
        this.task = data;
        this.parentTask = this.task.parentTask;
                       
      }, err => {alert('Service temporarily unavailable')});
        
    });

    this.taskService.getTaskList().subscribe(data => {
      this.taskArr = data;
    }, err => {alert('Service temporarily unavailable')});
      
  }

  updateTask(){

    this.taskService.updateTask(this.task).subscribe(data => {
      this.task = data;
      //alert('Task sucessfully updated');
      this._router.navigate(['/viewAll']);
            
      }, err => {alert('Service temporarily unavailable')}
    );
  }

  cancelTask(){
    this._router.navigate(['/viewAll']);
  }


}
