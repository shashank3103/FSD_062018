import { Component, OnInit } from '@angular/core';
import {TaskService} from '../../shared_service/task.service';
import {Task} from '../../entity/task'
import {Router} from '@angular/router';

@Component({
  selector: 'app-task-form',
  templateUrl: './task-form.component.html',
  styleUrls: ['./task-form.component.css']
})
export class TaskFormComponent implements OnInit {
  private task:Task;
  private tasks:Task[];
  private taskSelected:Number;
  private modifyText:String;

  constructor(private _taskService:TaskService, private _router:Router) { }

  ngOnInit() {
    this.task=  this._taskService.getter();
    // this._taskService.getTasks().subscribe((tasks)=>{
    //  console.log(tasks);
    //  this.tasks=tasks;})

    //this.taskSelected=this.task.taskId;

  }

  processForm(){
    if(this.task.taskId==undefined){
      console.log(this.task); 
      this._taskService.addTask(this.task).subscribe((task)=>{
         
         this._router.navigate(['/View Task']);
       },(error)=>{
         console.log(error);
       });
    }else{
      console.log(this.task);
       this._taskService.updateTask(this.task).subscribe((task)=>{
         console.log(task);
         this._router.navigate(['/View Task']);
       },(error)=>{
         console.log(error);
       });
    }
  }

  onTaskSelected(val:any){
    this.customText(val);
  }

  customText(val:any){
    this.modifyText= "DD value : " + val;
  }
}