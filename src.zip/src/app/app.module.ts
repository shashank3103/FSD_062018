import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {HttpModule} from '@angular/http';
import {TaskService} from './shared_service/task.service';
import {FormsModule} from '@angular/forms';
//import {MatSliderModule} from '@angular/material/slider';

import { AppComponent } from './app.component';
//import { ListtaskComponent } from './components/listtask/listtask.component';
import { TaskFormComponent } from './components/task-form/task-form.component';
import { AddTaskComponent } from './components/add-task/add-task.component';
import { ViewTaskComponent } from './components/view-task/view-task.component';
//import { TaskService } from './task.service';
import { EditTaskComponent } from './components/edit-task/edit-task.component';
import { ComboSearchPipePipe } from './shared_service/combo-search-pipe.pipe';

const appRoutes:Routes=[
  { path: 'addTask', component: AddTaskComponent },
  { path: 'viewAll', component: ViewTaskComponent },
  { path: '', component: ViewTaskComponent },
  { path: 'editTask/:taskId', component: EditTaskComponent }
  ];

@NgModule({
  declarations: [
    AppComponent,
    //ListtaskComponent,
    TaskFormComponent,
    AddTaskComponent,
    ViewTaskComponent,
    EditTaskComponent,
    ComboSearchPipePipe
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [TaskService],
  bootstrap: [AppComponent]
})
export class AppModule { }
