import { Parent } from "./parent";

export class Task {
    public taskId : number;
    public taskName : string;
    public priority : number;
    public startDate : Date;
    public endDate : Date;
    public actualStartDate : Date;
    public actualEndDate : Date;
    public parentTask : Parent;
    public editFlag : boolean = true;
    public parentName : string;
    public pId : number;

    /*
    public taskId:number;
	public parentTask:Task;
	private task:String;
	private startDate:String;
	private endDate:String;
	private priority:number;
    */

    constructor(){
        
    }
    
}
