/**
 * 
 */
package com.sg.capsule.taskManager;

import org.junit.runner.RunWith;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import com.sg.capsule.taskManager.dao.ITaskManagerDAO;
import com.sg.capsule.taskManager.dto.Task;
import com.sg.capsule.taskManager.service.ITaskManagerServiceImpl;

/**
 * 
 *
 */

@RunWith(SpringRunner.class)
public class ITaskManagerServiceImplTest {
	
	@TestConfiguration
    static class TaskManagerServiceImplTestContextConfiguration {
  
        @Bean
        public ITaskManagerServiceImpl taskManagerServiceImpl() {
            return new ITaskManagerServiceImpl();
        }
	}
	
	@Autowired
    private ITaskManagerServiceImpl taskManagerService;
 
    @MockBean
    private ITaskManagerDAO taskManagerDAO;
    
    @Before
    public void setUp() {
        Task task = new Task();
        task.setTaskId(Long.valueOf(111));
        task.setTaskName("t2");
                
        Optional<Task> opt = Optional.of(task);
        Mockito.when(taskManagerDAO.findById(task.getTaskId()))
          .thenReturn(opt);
        taskManagerService.setTaskManagerDAO(taskManagerDAO);
        
    }
    
    @Test
    public void whenValidName_thenTaskShouldBeFound() {
        Long id = new Long(111);
        String taskName = "t2";
        Task foundTask = taskManagerService.getTaskByID(id);
      
         assertThat(foundTask.getTaskName())
          .isEqualTo(taskName);
     }
    
    @Test
    public void whenValidName_thenTaskShouldNotBeFound() {
        Long id = new Long(111);
        String taskName = "t2";
        Task foundTask = taskManagerService.getTaskByID(id);
      
         assertThat(foundTask.getTaskName())
          .isEqualTo(taskName);
     }


}
