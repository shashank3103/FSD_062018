package com.sg.capsule.taskManager;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SpringBootTaskManagerApplicationTests {

	@Test
	public void contextLoads() {
	}

}
