/**
 * 
 */
package com.sg.capsule.taskManager.util;

import org.springframework.beans.factory.annotation.Value;

/**
 * @author Shashank
 *
 */

public class ConfigProperties {
	
	@Value( "${test.controller.task.id}" )
	private String testCntrTaskId;
	
	@Value( "${test.controller.task.name}" )
	private String testCntrTaskName;
	
	@Value( "${test.controller.task.size}" )
	private int testCntrTaskSize;
	
	@Value( "${test.dao.task.name}" )
	private String testDaoTaskName;
	
	@Value( "${test.dao.task.id}" )
	private String testDaoTaskId;

	public String getTestCntrTaskId() {
		return testCntrTaskId;
	}

	public void setTestCntrTaskId(String testCntrTaskId) {
		this.testCntrTaskId = testCntrTaskId;
	}

	public String getTestCntrTaskName() {
		return testCntrTaskName;
	}

	public void setTestCntrTaskName(String testCntrTaskName) {
		this.testCntrTaskName = testCntrTaskName;
	}

	public int getTestCntrTaskSize() {
		return testCntrTaskSize;
	}

	public void setTestCntrTaskSize(int testCntrTaskSize) {
		this.testCntrTaskSize = testCntrTaskSize;
	}

	public String getTestDaoTaskName() {
		return testDaoTaskName;
	}

	public void setTestDaoTaskName(String testDaoTaskName) {
		this.testDaoTaskName = testDaoTaskName;
	}

	public String getTestDaoTaskId() {
		return testDaoTaskId;
	}

	public void setTestDaoTaskId(String testDaoTaskId) {
		this.testDaoTaskId = testDaoTaskId;
	}



}
