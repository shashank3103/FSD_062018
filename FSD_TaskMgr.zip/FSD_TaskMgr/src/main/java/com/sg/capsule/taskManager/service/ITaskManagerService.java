/**
 * 
 */
package com.sg.capsule.taskManager.service;

import java.util.List;

import com.sg.capsule.taskManager.dto.Task;

/**
 * @author Shashank
 *
 */
public interface ITaskManagerService {

	List<Task> getAllTasks();
	
	Task getTaskByID(Long taskId);
		
	boolean saveTask(Task task);
	
	boolean updateTask(Task task);
	
	boolean deleteTask(Long taskId);
}
