/**
 * 
 */
package com.sg.capsule.taskManager.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sg.capsule.taskManager.dto.Task;

/**
 * @author Shashank
 *
 */

@Repository
public interface ITaskManagerDAO extends JpaRepository<Task, Long> {
	
}
 