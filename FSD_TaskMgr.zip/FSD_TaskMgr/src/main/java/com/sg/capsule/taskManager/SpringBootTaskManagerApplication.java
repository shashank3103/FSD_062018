package com.sg.capsule.taskManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootTaskManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootTaskManagerApplication.class, args);
	}
}
